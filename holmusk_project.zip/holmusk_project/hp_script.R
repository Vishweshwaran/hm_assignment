library(lubridate)
library(dplyr)
#load data
bill_amount<-read.csv("./input_data/bill_amount.csv",header=TRUE,stringsAsFactors = FALSE)
bill_id<-read.csv(file="./input_data/bill_id.csv",header=TRUE,stringsAsFactors = FALSE)
clinical_data<-read.csv(file="./input_data/clinical_data.csv",header=TRUE,stringsAsFactors = FALSE)
demographic_data<-read.csv(file="./input_data/demographics.csv",header=TRUE,stringsAsFactors = FALSE)
#clean up
clinical_data$medical_history_3[clinical_data$medical_history_3=="Yes"]<-0
clinical_data$medical_history_3[clinical_data$medical_history_3=="No"]<-1
clinical_data$medical_history_3<-as.numeric(clinical_data$medical_history_3)
demographic_data$gender[demographic_data$gender=="m"]<-"Male"
demographic_data$gender[demographic_data$gender=="f"]<-"Female"
demographic_data$race[demographic_data$race=="India"]<-"Indian"
demographic_data$race[demographic_data$race=="chinese"]<-"Chinese"

#Joins 
total <- merge(bill_amount,bill_id,by="bill_id")
bill_agg <- aggregate(list(total$amount), by = list(total$patient_id, total$date_of_admission), sum)
colnames(bill_agg)[1] <- "patient_id"
colnames(bill_agg)[2] <- "date_of_admission"
colnames(bill_agg)[3] <- "total_amount"

bill_agg$year<-year(bill_agg$date_of_admission)
pre_combined_data<-merge(bill_agg,demographic_data,by="patient_id")
pre_combined_data$age<-age2(pre_combined_data)
complete_data<-merge(pre_combined_data,clinical_data,by.x=c("patient_id", "date_of_admission"), by.y=c("id", "date_of_admission"))
complete_data$noofdays<-noofdays(complete_data)
complete_data$bmi<-as.numeric(complete_data$weight/((complete_data$height/100)*(complete_data$height/100)))
complete_data$mh_count<-data_count(complete_data,11,17)
complete_data$preop_count<-data_count(complete_data,18,23)
complete_data$symp_count<-data_count(complete_data,24,28)
#split data by years
unique(complete_data$year)
complete_data1<-filter(complete_data,year %in% "2011")
complete_data2<-filter(complete_data,year %in% "2012")
complete_data3<-filter(complete_data,year %in% "2013")
complete_data4<-filter(complete_data,year %in% "2014")
complete_data5<-filter(complete_data,year %in% "2015")
#identify outliers
newdata = complete_data[,c(3,11:14)]
plot(newdata, pch=16, col="blue", main="Total Cost vs Medical History")
plot(newdata, pch=16, col="blue", main="Total Cost vs Medical History 1 to 4")
newdata = complete_data[,c(3,15:17)]
plot(newdata, pch=16, col="blue", main="Total Cost vs Medical History 5 to 7")


#Remove outliers
cd_out<-complete_data[(complete_data$total_amount/1000 <= 80), ]
cd_out1<-filter(cd_out,year %in% "2011")
cd_out2<-filter(cd_out,year %in% "2012")
cd_out3<-filter(cd_out,year %in% "2013")
cd_out4<-filter(cd_out,year %in% "2014")
cd_out5<-filter(cd_out,year %in% "2015")

#Plots
boxplot((total_amount/1000)~age,data=complete_data, main="Cost Vs age",xlab="age", ylab="Cost * 1000")
boxplot((total_amount/1000)~bmi,data=complete_data, main="Cost Vs bmi",xlab="bmi", ylab="Cost * 1000")
boxplot((total_amount/1000)~gender,data=complete_data, main="Cost Vs Gender",xlab="Gender", ylab="Cost * 1000")
boxplot((total_amount/1000)~mh_count,data=complete_data, main="Cost Vs Medical History",xlab="No of Medical History", ylab="Cost * 1000")
boxplot((total_amount/1000)~noofdays,data=complete_data, main="Cost Vs No of days of treatment",xlab="No of days", ylab="Cost * 1000")
boxplot((total_amount/1000)~race,data=complete_data, main="Cost Vs Race",xlab="Race", ylab="Cost * 1000")
boxplot((total_amount/1000)~symp_count,data=complete_data, main="Cost Vs Symptoms",xlab="No of Symptoms", ylab="Cost * 1000")
boxplot((total_amount/1000)~year,data=complete_data, main="Cost Vs year",xlab="year", ylab="Cost * 1000")
boxplot((total_amount/1000)~preop_count,data=complete_data, main="Cost Vs Preop Medication",xlab="No of Preop Medication", ylab="Cost * 1000")
boxplot((total_amount/1000)~medical_history_1,data=complete_data, main="Cost vs Medical History 1",xlab="Medical History 1", ylab="Cost * 1000")
boxplot((total_amount/1000)~medical_history_2,data=complete_data, main="Cost vs Medical History 2",xlab="Medical History 2", ylab="Cost * 1000")
boxplot((total_amount/1000)~medical_history_3,data=complete_data, main="Cost vs Medical History 3",xlab="Medical History 3", ylab="Cost * 1000")
boxplot((total_amount/1000)~medical_history_4,data=complete_data, main="Cost vs Medical History 4",xlab="Medical History 4", ylab="Cost * 1000")
boxplot((total_amount/1000)~medical_history_5,data=complete_data, main="Cost vs Medical History 5",xlab="Medical History 5", ylab="Cost * 1000")
boxplot((total_amount/1000)~medical_history_6,data=complete_data, main="Cost vs Medical History 6",xlab="Medical History 6", ylab="Cost * 1000")
boxplot((total_amount/1000)~medical_history_7,data=complete_data, main="Cost vs Medical History 7",xlab="Medical History 7", ylab="Cost * 1000")
boxplot((total_amount/1000)~preop_medication_1,data=complete_data, main="Cost vs preop_medication_1",xlab="preop_medication_1", ylab="Cost * 1000")
boxplot((total_amount/1000)~preop_medication_2,data=complete_data, main="Cost vs preop_medication_2",xlab="preop_medication_2", ylab="Cost * 1000")
boxplot((total_amount/1000)~preop_medication_3,data=complete_data, main="Cost vs preop_medication_3",xlab="preop_medication_3", ylab="Cost * 1000")
boxplot((total_amount/1000)~preop_medication_4,data=complete_data, main="Cost vs preop_medication_4",xlab="preop_medication_4", ylab="Cost * 1000")
boxplot((total_amount/1000)~preop_medication_5,data=complete_data, main="Cost vs preop_medication_5",xlab="preop_medication_5", ylab="Cost * 1000")
boxplot((total_amount/1000)~preop_medication_6,data=complete_data, main="Cost vs preop_medication_6",xlab="preop_medication_6", ylab="Cost * 1000")
boxplot((total_amount/1000)~symptom_1,data=complete_data, main="Cost vs symptom_1",xlab="symptom_1", ylab="Cost * 1000")
boxplot((total_amount/1000)~symptom_2,data=complete_data, main="Cost vs symptom_2",xlab="symptom_2", ylab="Cost * 1000")
boxplot((total_amount/1000)~symptom_3,data=complete_data, main="Cost vs symptom_3",xlab="symptom_3", ylab="Cost * 1000")
boxplot((total_amount/1000)~symptom_4,data=complete_data, main="Cost vs symptom_4",xlab="symptom_4", ylab="Cost * 1000")
boxplot((total_amount/1000)~symptom_5,data=complete_data, main="Cost vs symptom_5",xlab="symptom_5", ylab="Cost * 1000")

#lm model
fit1<-lm(formula = total_amount ~  age + medical_history_1 + medical_history_2 + medical_history_3 + medical_history_4 + medical_history_5 + medical_history_6 + medical_history_7  +symptom_1 + symptom_2 + symptom_3 + symptom_4 + symptom_5 + gender + race  + bmi, data=cd_out, na.action = na.omit)
summary(fit1)


fit2<-lm(formula = total_amount ~  age + medical_history_1 + medical_history_2 + medical_history_5 + medical_history_6 + medical_history_7  +symptom_1 + symptom_2 + symptom_3 + symptom_4 + symptom_5 + gender + race  + bmi, data=cd_out, na.action = na.omit)
summary(fit2)


fit3<-lm(formula = total_amount ~  age + medical_history_1 + medical_history_2 + medical_history_3 + medical_history_4 + medical_history_5 + medical_history_6 + medical_history_7  +symptom_1 + symptom_2 + symptom_3 + symptom_4 + symptom_5 + gender + race  + bmi, data=complete_data, na.action = na.omit)
summary(fit3)

fit2011<-lm(formula = total_amount ~  age + medical_history_1 + medical_history_2 + medical_history_5 + medical_history_6 + medical_history_7  +symptom_1 + symptom_2 + symptom_3 + symptom_4 + symptom_5 + gender + race  + bmi, data=cd_out1, na.action = na.omit)
summary(fit2011)

fit4<-lm(formula = total_amount ~  age + medical_history_1 + medical_history_2  + medical_history_5 + medical_history_6 + medical_history_7  +symptom_1 + symptom_2 + symptom_3 + symptom_4 + symptom_5 + gender + race  + bmi, data=complete_data, na.action = na.omit)
summary(fit4)

fit2012<-lm(formula = total_amount ~  age + medical_history_1 + medical_history_2 + medical_history_5 + medical_history_6 + medical_history_7  +symptom_1 + symptom_2 + symptom_3 + symptom_4 + symptom_5 + gender + race  + bmi, data=cd_out2, na.action = na.omit)
summary(fit2012)

fit2013<-lm(formula = total_amount ~  age + medical_history_1 + medical_history_2 + medical_history_5 + medical_history_6 + medical_history_7  +symptom_1 + symptom_2 + symptom_3 + symptom_4 + symptom_5 + gender + race  + bmi, data=cd_out3, na.action = na.omit)
summary(fit2013)

fit2014<-lm(formula = total_amount ~  age + medical_history_1 + medical_history_2 + medical_history_5 + medical_history_6 + medical_history_7  +symptom_1 + symptom_2 + symptom_3 + symptom_4 + symptom_5 + gender + race  + bmi, data=cd_out4, na.action = na.omit)
summary(fit2014)


fit2015<-lm(formula = total_amount ~  age + medical_history_1 + medical_history_2 + medical_history_5 + medical_history_6 + medical_history_7  +symptom_1 + symptom_2 + symptom_3 + symptom_4 + symptom_5 + gender + race  + bmi, data=cd_out5, na.action = na.omit)
summary(fit2015)

cd_fit2011<-lm(formula = total_amount ~  age + medical_history_1 + medical_history_2 + medical_history_5 + medical_history_6 + medical_history_7  +symptom_1 + symptom_2 + symptom_3 + symptom_4 + symptom_5 + gender + race  + bmi, data=complete_data1, na.action = na.omit)
summary(cd_fit2011)

cd_fit2012<-lm(formula = total_amount ~  age + medical_history_1 + medical_history_2 + medical_history_5 + medical_history_6 + medical_history_7  +symptom_1 + symptom_2 + symptom_3 + symptom_4 + symptom_5 + gender + race  + bmi, data=complete_data2, na.action = na.omit)
summary(cd_fit2012)

cd_fit2013<-lm(formula = total_amount ~  age + medical_history_1 + medical_history_2 + medical_history_5 + medical_history_6 + medical_history_7  +symptom_1 + symptom_2 + symptom_3 + symptom_4 + symptom_5 + gender + race  + bmi, data=complete_data3, na.action = na.omit)
summary(cd_fit2013)

cd_fit2014<-lm(formula = total_amount ~  age + medical_history_1 + medical_history_2 + medical_history_5 + medical_history_6 + medical_history_7  +symptom_1 + symptom_2 + symptom_3 + symptom_4 + symptom_5 + gender + race  + bmi, data=complete_data4, na.action = na.omit)
summary(cd_fit2014)

cd_fit2015<-lm(formula = total_amount ~  age + medical_history_1 + medical_history_2 + medical_history_5 + medical_history_6 + medical_history_7  +symptom_1 + symptom_2 + symptom_3 + symptom_4 + symptom_5 + gender + race  + bmi, data=complete_data5, na.action = na.omit)
summary(cd_fit2015)

#Functions to get age
age_years <- function(from, to)
{
  lt <- as.POSIXlt(c(from, to))
  age <- lt$year[2] - lt$year[1]
  mons <- lt$mon + lt$mday/50
  if(mons[2] < mons[1]) age <- age -1
  age
}

age2 <- function(data){
  age<-c()
  for(i in 1:nrow(data)){
    age1<-age_years(as.Date(data$date_of_birth[i]),as.Date(data$date_of_admission[i]))
    age<-c(age,age1)
  }
  return(age)
}

noofdays <- function(data){
  days<-c()
  for(i in 1:nrow(data)){
    days1<-(as.Date(data$date_of_discharge[i])-(as.Date(data$date_of_admission[i])))
    days<-c(days,days1)
  }
  return(days)
}

data_count <- function(data,col_ind1,col_ind2){
  #col_names<-colnames(complete_data)
  #sub_col_names<-col_names[col_ind]
  f_count<-c()
  for(i in 1:nrow(data)){
    count = 0
    for(j in col_ind1:col_ind2 ){
      if(!is.na(data[i,j])){
        if((data[i,j]) == 0){
          count=count + 1
        } 
      }
      #print(count)		
    }
    f_count<-c(f_count,count)		
  }
  return(f_count)
}
